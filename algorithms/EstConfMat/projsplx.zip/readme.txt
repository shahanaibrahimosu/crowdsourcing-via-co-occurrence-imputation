Projection onto simplex

mex file included
pre-compiled for matlab (linux/win 32/64bit)

syntax:
x = projsplx(y);

(c) Xiaojing Ye
Email: xye@ufl.edu
Web: http://www.math.ufl.edu/~xye
Department of Mathematics
University of Florida
Gainesville, FL 32611

Paper link: 
http://ufdc.ufl.edu/IR00000353/
http://arxiv.org/abs/1101.6081
1/15/2011
